% Question 2 bilinear interpolation implementation
function [ output ] = bilinearInterpolation( image, x, y )
    k = floor(x);
    l = floor(y);
    a = x - k;
    b = y - l;
    output = (1-a)*(1-b)*image(k,l) + (1-a)*b*image(k, l+1) + a*b*image(k+1,l+1) + a*(1-b)*image(k+1, l);
end
