% Projection Matrix function for Question 5
function output = createProjectionMatrix( xy, uv )
    output = [];
    for i = 1:length(xy)
        vec1 = [uv(i,1),uv(i,2),1,0,0,0,-xy(i,1)*uv(i,1),-xy(i,1)*uv(i,2),-xy(i,1)];
        vec2 = [0,0,0,uv(i,1),uv(i,2),1,-xy(i,2)*uv(i,1),-xy(i,2)*uv(i,2),-xy(i,2)];
        output = [output; vec1; vec2];
    end
end

