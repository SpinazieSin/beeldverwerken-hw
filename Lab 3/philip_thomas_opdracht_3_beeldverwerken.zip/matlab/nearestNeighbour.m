% Question 2 nearest neighbour implementation
function [ output ] = nearestNeighbour( image, x, y )
    round_x = round(x);
    round_y = round(y);
    output = image(round_x, round_y);
end

