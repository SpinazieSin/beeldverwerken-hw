% Function for Question 2, returns pixel value based on a given method
function output = pixelValue( image, x, y, method )
    if inImage(image, x, y)
        switch(method)
            case 'nearest'
                output = nearestNeighbour(image, x, y);
            case 'linear'
                output = bilinearInterpolation(image, x, y);
        end
    else
        output = 0;
    end
end

