% Create Projection for Question 5
function projection = myProjection( image, points, m, n, method)
    projection = zeros(n,m);
    uv = points;
    xy = [1,1;n,1;n,m;1,m];
    projection_vector = null(createProjectionMatrix(uv, xy));
    projection_matrix = reshape(projection_vector, 3, 3)';
    for xIndex = 1:m
        for yIndex = 1:n
            result_pos = projection_matrix*[xIndex; yIndex; 1];
            projection(xIndex, yIndex) = pixelValue(image, result_pos(1)/result_pos(3), result_pos(2)/result_pos(3), method);
        end
    end
end

